import React from 'react';
import DevCard from './DevCard';

export default function Challenge1({ devs }) {
  const { devContainerStyle } = styles;

  return (
    <div className='center'>
      <h2>
        Desafio 1 - Implementar estrelas para Junior (1), Pleno (2) e Senior (3)
      </h2>

      <h3>{devs.length} dev(s) encontrado(s)</h3>

      <div className='center' style={devContainerStyle}>
        {devs.map((dev) => (
          <DevCard key={dev.id} dev={dev} />
        ))}
      </div>
    </div>
  );
}

const styles = {
  devContainerStyle: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },
};
