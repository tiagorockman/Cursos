import React from 'react';
import Languages from './Languages';

export default function DevCard({ dev }) {
  const { name, email, age, programmingLanguages, picture } = dev;
  const { flexRowStyle, avatarStyle, cardStyle, emailStyle } = styles;

  return (
    <div style={cardStyle}>
      <div style={flexRowStyle}>
        <img style={avatarStyle} src={picture} alt={name} />
        <ul style={{ textAlign: 'left' }}>
          <li>
            <strong>{name}</strong>, <em>{age}</em> anos
          </li>
          <li style={emailStyle}>{email}</li>
          <li>
            <Languages languages={programmingLanguages} />
          </li>
        </ul>
      </div>
    </div>
  );
}

const styles = {
  cardStyle: {
    display: 'flex',
    width: '390px',
    height: '150px',
    padding: '10px',
    border: '1px solid lightgray',
    borderRadius: '5px',

    margin: '10px',
  },

  flexRowStyle: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarStyle: {
    width: '100px',
    height: '100px',
    borderRadius: '50%',
    marginRight: '20px',
  },

  emailStyle: {
    color: 'navy',
    textDecoration: 'underline',
    cursor: 'pointer',
  },
};
