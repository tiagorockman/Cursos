import React from 'react';
import Language from './Language';

export default function Languages({ languages }) {
  return (
    <div style={{ marginTop: '10px' }}>
      {languages.map((language) => (
        <Language key={language.id} language={language} />
      ))}
    </div>
  );
}
