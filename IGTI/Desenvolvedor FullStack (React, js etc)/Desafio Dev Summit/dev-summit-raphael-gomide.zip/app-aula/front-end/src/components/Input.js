import React from 'react';

export default function Input({ value, description }) {
  const id = Math.random().toString();

  const { inputStyle } = styles;

  return (
    <div className='input-field'>
      <input style={inputStyle} id={id} type='text' value={value} readOnly />
      <label htmlFor={id} className='active'>
        {description}
      </label>
    </div>
  );
}

const styles = {
  inputStyle: {
    margin: '5px',
    padding: '5px',
    width: '300px',
  },
};
