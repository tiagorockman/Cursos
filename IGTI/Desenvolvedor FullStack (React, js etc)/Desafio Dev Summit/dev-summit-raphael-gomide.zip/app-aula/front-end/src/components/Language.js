import React from 'react';

const FULL_STAR = '★';
const EMPTY_STAR = '☆';
const MAX_STARS = 3;

export default function Language({ language }) {
  const { language: name, level = 0 } = language;

  const fullStars = FULL_STAR.repeat(level);
  const emptyStars = EMPTY_STAR.repeat(MAX_STARS - level);

  const { fullStarStyle, emptyStarStyle } = styles;

  return (
    <div>
      <span style={fullStarStyle}>{fullStars}</span>
      <span style={emptyStarStyle}>{emptyStars}</span> {name}
    </div>
  );
}

const styles = {
  fullStarStyle: {
    color: '#e67e22',
    fontWeight: 'bold',
  },

  emptyStarStyle: {
    color: '#e67e22',
  },
};
