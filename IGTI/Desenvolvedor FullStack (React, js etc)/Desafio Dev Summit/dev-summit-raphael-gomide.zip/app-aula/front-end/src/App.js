import React, { useEffect, useState } from 'react';

import M from 'materialize-css';

import Challenge1 from './components/Challenge1';
import Challenge2 from './components/Challenge2';
import Challenge3 from './components/Challenge3';
import Spinner from './components/Spinner';

export default function App() {
  const [devs, setDevs] = useState([]);

  useEffect(() => {
    document.title = 'React Devs v1.0.1';
  }, []);

  useEffect(() => {
    M.AutoInit();
  }, [devs]);

  useEffect(() => {
    const fetchDevs = async () => {
      const resource = await fetch('http://localhost:3001/devs');
      const json = await resource.json();

      const newDevs = json
        .filter((_, index) => index < 500)
        .map((item) => {
          const { programmingLanguages } = item;

          const newLanguages = programmingLanguages.map((language) => {
            const { experience } = language;

            return {
              ...language,
              level:
                experience === 'Junior' ? 1 : experience === 'Pleno' ? 2 : 3,
            };
          });

          return { ...item, programmingLanguages: newLanguages };
        });

      // Desafio 1

      setDevs(newDevs);
    };

    fetchDevs();
  }, []);

  return (
    <div className='container'>
      <h1 className='center'>Developers</h1>

      {devs.length === 0 ? (
        <Spinner />
      ) : (
        <>
          <ul className='tabs tabs-fixed-width'>
            <li className='tab col s3'>
              <a className='active' href='#challenge1'>
                Desafio 1
              </a>
            </li>

            <li className='tab col s3'>
              <a className='active' href='#challenge2'>
                Desafio 2
              </a>
            </li>

            <li className='tab col s3'>
              <a className='active' href='#challenge3'>
                Desafio 3
              </a>
            </li>
          </ul>
          <div id='challenge1' className='col s12'>
            <Challenge1 devs={devs} />
          </div>

          <div id='challenge2' className='col s12'>
            <Challenge2 devs={devs} />
          </div>

          <div id='challenge3' className='col s12'>
            <Challenge3 devs={devs} />
          </div>
        </>
      )}
    </div>
  );
}
