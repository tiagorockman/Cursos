const fs = require('fs').promises;
const { uuid } = require('uuidv4');

const languages = ['Java', 'JavaScript', 'Python'];
const experiences = ['Junior', 'Pleno', 'Senior'];

function generateNumber(from = 0, to = 10) {
  return Math.max(from, Math.floor(Math.random() * to));
}

let trues = 0;
let falses = 0;

function flipCoin() {
  let boolean = Number(Math.random().toFixed(2)[3]) % 2 === 0;

  if (boolean) {
    trues++;

    if (trues === 2) {
      trues = 0;
      boolean = false;
    }
  } else {
    falses++;

    if (falses === 2) {
      falses = 0;
      boolean = true;
    }
  }

  return boolean;
}

async function generate() {
  const stringArray = await fs.readFile('./files/users.json', 'utf-8');
  const json = JSON.parse(stringArray);

  const devs = json.results
    //.filter((_, index) => index < 100)
    .map((user) => {
      const { name, email, dob, picture, cell, login } = user;

      const programmingLanguages = getRandomLanguages();

      return {
        id: uuid(),
        name: `${name.first} ${name.last}`,
        email,
        age: dob.age,
        picture: picture.large,
        programmingLanguages,
      };
    });

  const devsObj = {
    devs,
  };

  await fs.writeFile('./files/devs.json', JSON.stringify(devsObj, null, 2));
  await fs.copyFile('./files/devs.json', '../api/devs.json');
}

function getRandomLanguages() {
  const randomExperiences = [];

  languages.forEach((language) => {
    if (flipCoin()) {
      randomExperiences.push({
        id: language,
        language,
        experience: experiences[generateNumber(0, 3)],
      });
    }
  });

  return randomExperiences;
}

generate();
