import React, { useState, useEffect } from 'react';

import DevCard from './DevCard';

const JAVA = 'Java';
const JAVA_SCRIPT = 'JavaScript';
const PYTHON = 'Python';

const JUNIOR = 'Junior';
const PLENO = 'Pleno';
const SENIOR = 'Senior';

export default function Challenge2({ devs }) {
  const [filteredDevs, setFilteredDevs] = useState([...devs]);

  const [languages, setLanguages] = useState([
    { id: JAVA, filter: true },
    { id: JAVA_SCRIPT, filter: true },
    { id: PYTHON, filter: true },
  ]);

  const [experiences, setExperiences] = useState([
    { id: JUNIOR, filter: true },
    { id: PLENO, filter: true },
    { id: SENIOR, filter: true },
  ]);

  const handleToggleLanguage = (languageId) => {
    const newLanguages = [...languages];
    const language = newLanguages.find((item) => item.id === languageId);
    language.filter = !language.filter;

    setLanguages(newLanguages);
  };

  const handleToggleExperience = (experienceId) => {
    const newExperiences = [...experiences];
    const experience = newExperiences.find((item) => item.id === experienceId);
    experience.filter = !experience.filter;

    setExperiences(newExperiences);
  };

  useEffect(() => {
    // Desafio 2
  }, [languages, experiences, devs]);

  const { devContainerStyle, checkboxesStyle, filterStyle } = styles;

  return (
    <div className='center'>
      <h2>Desafio 2 - Implementar filtros conforme os seguintes parâmetros</h2>

      <div style={filterStyle}>
        <div style={checkboxesStyle}>
          {languages.map((language) => {
            const { id, filter } = language;

            return (
              <label key={id}>
                <input
                  type='checkbox'
                  checked={filter}
                  onChange={() => handleToggleLanguage(id)}
                />
                <span>{id}</span>
              </label>
            );
          })}
        </div>

        <div style={checkboxesStyle}>
          {experiences.map((experience) => {
            const { id, filter } = experience;

            return (
              <label key={id}>
                <input
                  type='checkbox'
                  checked={filter}
                  onChange={() => handleToggleExperience(id)}
                />
                <span>{id}</span>
              </label>
            );
          })}
        </div>
      </div>

      <h3>{filteredDevs.length} dev(s) encontrado(s)</h3>

      <div className='center' style={devContainerStyle}>
        {filteredDevs.map((dev) => (
          <DevCard key={dev.id} dev={dev} />
        ))}
      </div>
    </div>
  );
}

const styles = {
  devContainerStyle: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
  },

  checkboxesStyle: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    marginLeft: '20px',
    padding: '10px',
  },

  filterStyle: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
};
