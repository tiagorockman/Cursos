import React from 'react';
import Input from './Input';

const devsByExperience = [
  { id: 'java_junior', language: 'Java', experience: 'Junior', count: 0 },
  { id: 'java_pleno', language: 'Java', experience: 'Pleno', count: 0 },
  { id: 'java_senior', language: 'Java', experience: 'Senior', count: 0 },
  {
    id: 'javascript_junior',
    language: 'JavaScript',
    experience: 'Junior',
    count: 0,
  },
  {
    id: 'javascript_pleno',
    language: 'JavaScript',
    experience: 'Pleno',
    count: 0,
  },
  {
    id: 'javascript_senior',
    language: 'JavaScript',
    experience: 'Senior',
    count: 0,
  },
  { id: 'python_junior', language: 'Python', experience: 'Junior', count: 0 },
  { id: 'python_pleno', language: 'Python', experience: 'Pleno', count: 0 },
  { id: 'python_senior', language: 'Python', experience: 'Senior', count: 0 },
];

export default function Challenge3({ devs }) {
  const { devContainerStyle } = styles;

  // prettier-ignore
  const sumAges = 
    devs.reduce((accumulator, current) => accumulator + current.age, 0);

  const averageAges = (sumAges / devs.length).toFixed(2);
  const devsSortedByAge = devs.sort((a, b) => a.age - b.age);

  const minAge = devsSortedByAge[0].age;
  const maxAge = devsSortedByAge[devsSortedByAge.length - 1].age;
  const minMaxAge = `${minAge} / ${maxAge}`;

  devs.forEach(({ programmingLanguages }) => {
    programmingLanguages.forEach(({ language, experience }) => {
      const id = `${language.toLowerCase()}_${experience.toLowerCase()}`;
      devsByExperience.find((dev) => dev.id === id).count++;
    });
  });

  const getDevsByExperience = (id) => {
    return devsByExperience.find((dev) => dev.id === id).count;
  };

  return (
    <div className='center'>
      <h2>Desafio 3 - Preencher as seguintes estatísticas</h2>

      <div style={devContainerStyle}>
        <Input value={sumAges} description='Soma das idades:' />
        <Input value={averageAges} description='Média das idades:' />
        <Input value={minMaxAge} description='Maior/menor idade:' />

        <Input
          value={getDevsByExperience('java_junior')}
          description='Quantidade de devs Java (Junior):'
        />
        <Input
          value={getDevsByExperience('java_pleno')}
          description='Quantidade de devs Java (Pleno):'
        />
        <Input
          value={getDevsByExperience('java_senior')}
          description='Quantidade de devs Java (Senior):'
        />

        <Input
          value={getDevsByExperience('javascript_junior')}
          description='Quantidade de devs JavaScript (Junior):'
        />
        <Input
          value={getDevsByExperience('javascript_pleno')}
          description='Quantidade de devs JavaScript (Pleno):'
        />
        <Input
          value={getDevsByExperience('javascript_senior')}
          description='Quantidade de devs JavaScript (Senior):'
        />

        <Input
          value={getDevsByExperience('python_junior')}
          description='Quantidade de devs Python (Junior):'
        />
        <Input
          value={getDevsByExperience('python_pleno')}
          description='Quantidade de devs Python (Pleno):'
        />
        <Input
          value={getDevsByExperience('python_senior')}
          description='Quantidade de devs Python (Senior):'
        />
      </div>
    </div>
  );
}

const styles = {
  devContainerStyle: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
    marginTop: '50px',
  },
};
