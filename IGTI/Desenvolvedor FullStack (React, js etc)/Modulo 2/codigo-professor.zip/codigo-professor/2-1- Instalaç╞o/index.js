import express from "express";

const app = express();
app.use(express.json());

//all
app.all("/testAll", (req, res) => {
    res.send(req.method);
});

//caracteres especiais
// ? define que a ultima letra é opcional
// /test também funciona
app.get("/teste?", (_, res) => {
    res.send("/teste?");
});

// + define que a ultima letra pode se repetir
// /buzzzzz funcionaria
app.get("/buzz+", (_, res) => {
    res.send("/buzz+");
});

// define o que estiver entre o * funciona
// /onetwoblue funciona
app.get("/one*Blue", (req, res) => {
    res.send(req.path);
});

// define o que está entre parenteses como opcional
app.post("/test(ing)?", (req, res) => {
    console.log(req.body);
    res.send("/test(ing)?");    
});

// expressao regular qualquer parametro que tiver Red no final entrará aqui
app.get(/.*Red$/, (req, res) => {
    console.log(req.body);
    res.send("/.*Red$/");    
});

//parametros na rota
app.get("/testParam/:id/:a?", (req, res) => {
    res.send(req.params.id + " " + req.params.a);
});

// http://localhost:3000/testQuery?nome=joao&email=xyz&cpf=12345
app.get("/testQuery", (req, res) => {
    res.send(req.query);
});

//next (executa com 2 callback)
app.get("/testMultipleHandlers", (req, res, next) => {
    console.log("Callback 1");
    next();
}, (req, res) => {
    console.log("Callback 2");
    res.end();
});

//next com array
const callback1 = (req, res, next) => {
    console.log("Callback 1");
    next();
};

function callback2 (req, res, next) {
    console.log("Callback 2");
    //next();
    res.end();
};

const callback3 = (req, res) => {
    console.log("Callback 3");
    res.end();
};

app.get("/testMultipleHandlersArray", [callback1, callback2, callback3]);

//route
app.route("/testRoute")
    .get((req, res) => {
        res.send("/testRoute GET");
    })
    .post((req, res) => {
        res.send("/testRoute POST");
    })
    .delete((req, res) => {
        res.send("/testRoute DELETE");
    });

app.listen(3000, () => {
    console.log("API Started!");
});