import React from 'react'

const Button = () => (
  <button>Olá =D{a}</button>
)

export default Button
