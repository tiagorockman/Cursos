import React from "react";
import Button from './Button'
const App = () => {
  return (
    <div>
      <p>Digital Innovation One</p>
      <p>Bem vindo a nossa aula =D.</p>
      <div>Webpack 4</div>
      <Button />
    </div>
  );
};
export default App;