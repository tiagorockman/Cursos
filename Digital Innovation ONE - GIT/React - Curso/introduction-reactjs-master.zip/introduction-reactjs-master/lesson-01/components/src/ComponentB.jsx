import React from 'react'

function ComponenteB(props) {
  return (
    <div>Componente B =D {props.children} </div>
  )
}

export default ComponenteB
